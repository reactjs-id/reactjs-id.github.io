self.__precacheManifest = [
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/./fonts/Foundation.ttf"
  },
  {
    "revision": "6a0c0b7296b546a044ea",
    "url": "/static/js/runtime~app.806c72c6.js"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/./fonts/Ionicons.ttf"
  },
  {
    "revision": "0ab6d0b68ff0f70fc75e",
    "url": "/static/js/2.b543e39d.chunk.js"
  },
  {
    "revision": "4c3d83ad8ea823175a09",
    "url": "/static/js/app.bcdeaf40.chunk.js"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/serve.json"
  },
  {
    "revision": "4e4e1e7b54bb31528d231215f128035e",
    "url": "/index.html"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/favicon.ico"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "d15c1216957060fac577af6151fb8cfe",
    "url": "/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/./fonts/Feather.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/./fonts/Entypo.ttf"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/./fonts/AntDesign.ttf"
  }
];